# Rishan's School App 🌟

A Progressive Web App (PWA) for Rishan Sreejith, Grade 2, GEMS Our Own Boys High School.

## Features
- 🏠 Home Dashboard with daily quote, today's schedule, pending homework
- 📅 Interactive Timetable — tap a weekday to highlight and view periods
- 📊 Grades with animated progress bars and letter grades
- 🏆 Achievement Badges (earned / locked)
- 📝 Homework Tracker with add/complete/delete
- ✅ Attendance Tracker with percentage circle
- 👤 Student Profile + School Info
- ⚙️ Admin Panel (PIN protected, default: 1234) to update everything
- 📱 Works offline (Service Worker)
- 🏠 Add to Home Screen (iOS & Android)

## Deploy to GitHub Pages

1. Create a new GitHub repo (e.g. `rishan-app`)
2. Upload all files keeping the folder structure:
   ```
   index.html
   admin.html
   sw.js
   manifest.json
   icons/
     icon-72.png ... icon-512.png
   ```
3. Go to Settings → Pages → Source: `main` branch → `/root`
4. Your app will be live at `https://YOUR_USERNAME.github.io/rishan-app/`

## Admin Panel
- URL: `https://your-app-url/admin.html`
- Default PIN: **1234**
- Change PIN in Settings tab
- You can update: Grades, Timetable, Badges, Attendance, Profile

## Add to iPhone Home Screen
1. Open the app URL in Safari
2. Tap the Share button (box with arrow)
3. Scroll down → "Add to Home Screen"
4. Tap "Add" — done! 🎉
